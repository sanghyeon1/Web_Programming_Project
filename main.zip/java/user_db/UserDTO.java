package user_db;

public class UserDTO {
	private String u_name;
	private String u_pw;
	private String u_id;
	private String u_sex;
	private String u_tall;
	private String u_weight;
	private String u_age;
	private String u_email;
	
	public UserDTO(String u_id, String u_name, String u_pw, String u_sex, String u_tall, String u_weight, String u_age, String u_email) {
		super();
		this.u_id = u_id;
		this.u_name = u_name;
		this.u_pw = u_pw;
		this.u_sex = u_sex;
		this.u_tall = u_tall;
		this.u_weight = u_weight;		
		this.u_age = u_age;
		this.u_email = u_email;
	}
	
	
	public String getU_id() {
		return u_id;
	}	
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	
	
	public String getU_name() {
		return u_name;
	}	
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	
	
	public String getU_pw() {
		return u_pw;
	}	
	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}	
	
	
	public String getU_sex() {
		return u_sex;
	}	
	public void setU_sex(String u_sex) {
		this.u_sex = u_sex;
	}		
	
	
	public String getU_tall() {
		return u_tall;
	}	
	public void setU_tall(String u_tall) {
		this.u_tall = u_tall;
	}
	
	
	public String getU_weight() {
		return u_weight;
	}	
	public void setU_weight(String u_weight) {
		this.u_weight = u_weight;
	}
	
	
	public String getU_age() {
		return u_age;
	}	
	public void setU_age(String u_age) {
		this.u_age = u_age;
	}
	
	
	public String getU_email() {
		return u_email;
	}	
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
}


