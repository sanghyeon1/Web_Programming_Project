package user_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDAO {
	private String jdbcDriver = "jdbc:mysql://localhost:3306/user_information?serverTimezone=UTC";
	private String dbUser = "root";
	private String dbPass = "1q2w3e4r";
	
	public UserDAO() {
	}
	
	// ������ �о����
	public ArrayList<UserDTO> UserSelect() {
		ArrayList<UserDTO> dtos = new ArrayList<UserDTO>();
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from users");
			
			while (rs.next()) {
				String u_id = rs.getString("u_id");
				String u_name = rs.getString("u_name");
				String u_pw = rs.getString("u_pw");
				String u_sex = rs.getString("u_sex");
				String u_tall = rs.getString("u_tall");
				String u_weight = rs.getString("u_weight");
				String u_age = rs.getString("u_age");
				String u_email = rs.getString("u_email");
				
				UserDTO dto = new UserDTO(u_id, u_name, u_pw, u_sex, u_tall, u_weight, u_age, u_email);
				dtos.add(dto);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return dtos;
	}
	
	public ArrayList<UserDTO> UserSelectOne(String user_name) {
		ArrayList<UserDTO> dtos = new ArrayList<UserDTO>();

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM users WHERE u_name = '"+ user_name + "'");
			
			while (rs.next()) {
				String u_id = rs.getString("u_id");
				String u_name = rs.getString("u_name");
				String u_pw = rs.getString("u_pw");
				String u_sex = rs.getString("u_sex");
				String u_tall = rs.getString("u_tall");
				String u_weight = rs.getString("u_weight");
				String u_age = rs.getString("u_age");
				String u_email = rs.getString("u_email");
				
				UserDTO dto = new UserDTO(u_id, u_name, u_pw, u_sex, u_tall, u_weight, u_age, u_email);
				dtos.add(dto);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}		
		return dtos;
	}
//	// ������ �ϳ��� �о����
//	public SubjectDTO subjectSelectOne(String code) {
//		Connection con = null;
//		Statement stmt = null;
//		ResultSet rs = null;
//		SubjectDTO dto = new SubjectDTO();
//		
//		try {
//			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
//			stmt = con.createStatement();
//			rs = stmt.executeQuery("select * from subject where sub_code = " + code);
//			
//			while (rs.next()) {
//				String sub_code = rs.getString("sub_code");
//				String sub_name = rs.getString("sub_name");
//				String sub_ename = rs.getString("sub_ename");
//				String create_year = rs.getString("create_year");
//				
//				dto = new SubjectDTO(sub_code, sub_name, sub_ename, create_year);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				if(rs != null) rs.close();
//				if(stmt != null) stmt.close();
//				if(con != null) con.close();
//			} catch(Exception e) {
//				e.printStackTrace();
//			}
//		}
//		
//		return dto;
//	}
//	
	// ������ ����
	public int insertUser(UserDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String query = "insert into Users (u_name, u_pw, u_sex, u_tall, u_weight, u_age, u_email) values (?, ?, ?, ?, ?, ?, ?)";
		int result = 0;
	
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, dto.getU_name());
			pstmt.setString(2, dto.getU_pw());
			pstmt.setString(3, dto.getU_sex());
			pstmt.setString(4, dto.getU_tall());
			pstmt.setString(5, dto.getU_weight());
			pstmt.setString(6, dto.getU_age());
			pstmt.setString(7, dto.getU_email());
			
			result = pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	// ������ ����
	public int deleteUser(String u_pw) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "delete from users where u_pw = ?";
		int result = 0;
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, u_pw);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}		
		return result;
	}
	
	//로그인 시 세션생성에 필요.
	private static UserDAO instance = new UserDAO();
	public static UserDAO getInstance() {
		return instance;
	}
	
	public int updateUser(UserDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "update users set u_name = ?, u_pw = ?, u_sex = ?, u_tall = ?, u_weight = ?, u_age = ?, u_email = ? where u_name = ?";
		int result = 0;
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, dto.getU_name());
			pstmt.setString(2, dto.getU_pw());
			pstmt.setString(3, dto.getU_sex());
			pstmt.setString(4, dto.getU_tall());
			pstmt.setString(5, dto.getU_weight());
			pstmt.setString(6, dto.getU_age());
			pstmt.setString(7, dto.getU_email());
			pstmt.setString(8, dto.getU_name());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return result;
	}

}